<?php
/*
Plugin Name: WP-Ban (Updated)
Description: Ban users by host name, user agent and referer url from visiting your WordPress blog. Updated with modern security and enhanced user agent detection. Updated by: minimax:)
Version: 2.0.0
Author: https://teskedsgumman.se
License: GPL v2 or later
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin version
define('WP_BAN_VERSION', '2.0.0');
define('WP_BAN_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WP_BAN_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Load text domain
 */
add_action('plugins_loaded', 'wp_ban_load_textdomain');
function wp_ban_load_textdomain() {
    load_plugin_textdomain('wp-ban', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}

/**
 * Add admin menu
 */
add_action('admin_menu', 'wp_ban_admin_menu');
function wp_ban_admin_menu() {
    add_options_page(
        __('Ban Settings', 'wp-ban'),
        __('Ban', 'wp-ban'),
        'manage_options',
        'wp-ban',
        'wp_ban_admin_page'
    );
}

/**
 * Admin page callback
 */
function wp_ban_admin_page() {
    include WP_BAN_PLUGIN_DIR . 'admin/ban-options.php';
}

/**
 * Wildcard matching
 */
function wp_ban_wildcard_match($pattern, $subject) {
    $pattern = preg_quote($pattern, '/');
    $pattern = str_replace('\\*', '.*', $pattern);
    return preg_match('/^' . $pattern . '$/i', $subject);
}

/**
 * Add settings link
 */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wp_ban_plugin_action_links');
function wp_ban_plugin_action_links($links) {
    $settings_link = '<a href="' . admin_url('options-general.php?page=wp-ban') . '">' . __('Settings', 'wp-ban') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

/**
 * Enqueue admin scripts and styles
 */
add_action('admin_enqueue_scripts', 'wp_ban_admin_scripts');
function wp_ban_admin_scripts($hook) {
    if ($hook != 'settings_page_wp-ban') return;
    
    wp_enqueue_style('wp-ban-admin', WP_BAN_PLUGIN_URL . 'assets/admin.css', array(), WP_BAN_VERSION);
    wp_enqueue_script('wp-ban-admin', WP_BAN_PLUGIN_URL . 'assets/admin.js', array('jquery'), WP_BAN_VERSION, true);
}

/**
 * Plugin deactivation
 */
register_deactivation_hook(__FILE__, 'wp_ban_deactivate');
function wp_ban_deactivate() {
    wp_cache_flush();
}

/**
 * Get visitor's real IP address
 */
function wp_ban_get_ip() {
    $banned_options = get_option('banned_options', array('reverse_proxy' => 0));

    if (!empty($banned_options['reverse_proxy']) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip_list = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ip_list[0]);
    }

    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
}

/**
 * Check if IP is within a range
 */
function wp_ban_check_ip_range($ip, $range) {
    if (strpos($range, '-') === false) return false;

    list($start, $end) = explode('-', $range);
    $start = trim($start);
    $end = trim($end);

    $ip_long = ip2long($ip);
    $start_long = ip2long($start);
    $end_long = ip2long($end);

    if ($ip_long === false || $start_long === false || $end_long === false) {
        return false;
    }

    return ($ip_long >= $start_long && $ip_long <= $end_long);
}

/**
 * Display banned message and exit
 */
function wp_ban_display_message() {
    $message = get_option('banned_message', '<div style="text-align: center; padding: 50px;"><h2>Access Denied</h2><p>You have been banned from accessing this site.</p></div>');

    // Replace variables
    $ip = wp_ban_get_ip();
    $hostname = gethostbyaddr($ip);

    $message = str_replace('%SITE_NAME%', get_bloginfo('name'), $message);
    $message = str_replace('%SITE_URL%', home_url(), $message);
    $message = str_replace('%USER_IP%', $ip, $message);
    $message = str_replace('%USER_HOSTNAME%', $hostname, $message);

    status_header(403);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><title>403 Forbidden</title></head><body>' . $message . '</body></html>';
    exit;
}

/**
 * Main ban check - runs on every request
 */
add_action('init', 'wp_ban_check', 1);
function wp_ban_check() {
    // Skip admin users
    if (is_admin() && current_user_can('manage_options')) {
        return;
    }

    $user_ip = wp_ban_get_ip();
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    $user_referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
    $user_hostname = @gethostbyaddr($user_ip);

    // Get ban lists
    $banned_ips = get_option('banned_ips', array());
    $banned_ip_range = get_option('banned_ip_range', array());
    $banned_hostnames = get_option('banned_hostnames', array());
    $banned_referers = get_option('banned_referers', array());
    $banned_user_agents = get_option('banned_user_agents', array());
    $allowed_user_agents = get_option('allowed_user_agents', array());
    $useragents_to_block = get_option('useragents_to_block', array());

    // Check allowed user agents first (whitelist takes priority)
    if (!empty($user_agent) && !empty($allowed_user_agents)) {
        foreach ($allowed_user_agents as $allowed) {
            if (!empty($allowed) && wp_ban_wildcard_match($allowed, $user_agent)) {
                return; // Allowed, skip all ban checks
            }
        }
    }

    // Check banned IPs
    if (!empty($banned_ips)) {
        foreach ($banned_ips as $banned_ip) {
            if (!empty($banned_ip) && wp_ban_wildcard_match($banned_ip, $user_ip)) {
                wp_ban_display_message();
            }
        }
    }

    // Check banned IP ranges
    if (!empty($banned_ip_range)) {
        foreach ($banned_ip_range as $range) {
            if (!empty($range) && wp_ban_check_ip_range($user_ip, $range)) {
                wp_ban_display_message();
            }
        }
    }

    // Check banned hostnames
    if (!empty($user_hostname) && !empty($banned_hostnames)) {
        foreach ($banned_hostnames as $banned_host) {
            if (!empty($banned_host) && wp_ban_wildcard_match($banned_host, $user_hostname)) {
                wp_ban_display_message();
            }
        }
    }

    // Check banned referers
    if (!empty($user_referer) && !empty($banned_referers)) {
        foreach ($banned_referers as $banned_ref) {
            if (!empty($banned_ref) && wp_ban_wildcard_match($banned_ref, $user_referer)) {
                wp_ban_display_message();
            }
        }
    }

    // Check banned user agents
    if (!empty($user_agent) && !empty($banned_user_agents)) {
        foreach ($banned_user_agents as $banned_ua) {
            if (!empty($banned_ua) && wp_ban_wildcard_match($banned_ua, $user_agent)) {
                wp_ban_display_message();
            }
        }
    }

    // Check useragents to block
    if (!empty($user_agent) && !empty($useragents_to_block)) {
        foreach ($useragents_to_block as $blocked_ua) {
            if (!empty($blocked_ua) && wp_ban_wildcard_match($blocked_ua, $user_agent)) {
                wp_ban_display_message();
            }
        }
    }
}

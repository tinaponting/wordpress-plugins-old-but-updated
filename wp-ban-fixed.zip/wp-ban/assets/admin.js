/**
 * WP-Ban Admin JavaScript
 */

jQuery(document).ready(function($) {
    
    // Add quick user agents
    $('#add-android-firefox').on('click', function(e) {
        e.preventDefault();
        
        var androidFirefoxAgents = [
            'Mozilla/5.0 (Android 2.0; Mobile; rv:7.0) Gecko/7.0 Firefox/7.0',
            'Mozilla/5.0 (Android 14; Mobile; rv:133.0) Gecko/133.0 Firefox/133.0'
        ];
        
        var $textarea = $('#banned_user_agents');
        var currentValue = $textarea.val();
        var newValue = currentValue;
        
        if (currentValue && !currentValue.endsWith('\n')) {
            newValue += '\n';
        }
        
        androidFirefoxAgents.forEach(function(agent) {
            if (newValue.indexOf(agent) === -1) {
                newValue += agent + '\n';
            }
        });
        
        $textarea.val(newValue.trim());
        
        $(this).text('Added!').prop('disabled', true);
        setTimeout(function() {
            $('#add-android-firefox').text('Add Android Firefox Strings').prop('disabled', false);
        }, 2000);
    });
    
    // Add common bots
    $('#add-common-bots').on('click', function(e) {
        e.preventDefault();
        
        var commonBots = [
            '*Bot*',
            '*Crawler*',
            '*Spider*',
            '*Scraper*',
            'EmailSiphon*',
            'LMQueueBot*',
            'ContactBot*'
        ];
        
        var $textarea = $('#banned_user_agents');
        var currentValue = $textarea.val();
        var newValue = currentValue;
        
        if (currentValue && !currentValue.endsWith('\n')) {
            newValue += '\n';
        }
        
        commonBots.forEach(function(bot) {
            if (newValue.indexOf(bot) === -1) {
                newValue += bot + '\n';
            }
        });
        
        $textarea.val(newValue.trim());
        
        $(this).text('Added!').prop('disabled', true);
        setTimeout(function() {
            $('#add-common-bots').text('Add Common Bots').prop('disabled', false);
        }, 2000);
    });
    
    // Form validation
    $('form').on('submit', function(e) {
        var currentIP = '<?php echo wp_ban_get_ip(); ?>';
        var bannedIPs = $('#banned_ips').val().split('\n');
        
        bannedIPs.forEach(function(bannedIP) {
            bannedIP = bannedIP.trim();
            if (bannedIP) {
                var regex = bannedIP.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                regex = regex.replace(/\\\*/g, '.*');
                var regexObj = new RegExp('^' + regex + '$', 'i');
                
                if (regexObj.test(currentIP)) {
                    if (!confirm('Warning: You may be banning your own IP address: ' + bannedIP + '. Continue?')) {
                        e.preventDefault();
                        return false;
                    }
                }
            }
        });
    });
});
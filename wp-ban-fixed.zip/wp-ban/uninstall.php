<?php
/**
 * Uninstall WP-Ban Plugin
 */

// Prevent direct access
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Clean up all plugin options
$options_to_delete = array(
    'banned_hosts', 
    'banned_stats',
    'banned_message',
    'banned_referers',
    'banned_user_agents',
    'banned_options'
);

// Delete options for single site
foreach ($options_to_delete as $option) {
    delete_option($option);
}

// Delete options for multisite
if (is_multisite()) {
    $sites = wp_get_sites();
    foreach ($sites as $site) {
        switch_to_blog($site['blog_id']);
        foreach ($options_to_delete as $option) {
            delete_option($option);
            delete_site_option($option);
        }
    }
    restore_current_blog();
}

// Clear cache
wp_cache_flush();
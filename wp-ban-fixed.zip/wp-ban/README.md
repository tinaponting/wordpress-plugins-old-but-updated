# WP-Ban (Updated)

A WordPress plugin to ban unwanted visitors by IP address, hostname, user agent, and referer URL.

![WordPress](https://img.shields.io/badge/WordPress-5.0%2B-blue)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-purple)
![License](https://img.shields.io/badge/License-GPL%20v2-green)

## Description

WP-Ban (Updated) allows you to block access to your WordPress site based on multiple criteria:

- **IP Addresses** - Block specific IPs or use wildcards (e.g., `192.168.1.*`)
- **IP Ranges** - Block entire IP ranges (e.g., `192.168.1.1-192.168.1.255`)
- **Hostnames** - Block by hostname with wildcard support (e.g., `*.cn`, `*.ru`)
- **Referers** - Block traffic from specific referrer URLs
- **User Agent Strings** - Block full browser user agent strings
- **Useragents to Block** - Block bots and crawlers using patterns (e.g., `*Blexbot*`, `*Python*`)
- **Allowed User Agents** - Whitelist specific user agents (e.g., `*Googlebot*`)

## Installation

### Method 1: WordPress Admin Upload

1. Download the `wp-ban.zip` file from [Releases](../../releases)
2. Go to your WordPress Admin Dashboard
3. Navigate to **Plugins > Add New > Upload Plugin**
4. Choose the `wp-ban.zip` file and click **Install Now**
5. Click **Activate Plugin**

### Method 2: FTP/Manual Upload

1. Download and extract the `wp-ban.zip` file
2. Upload the `wp-ban` folder to `/wp-content/plugins/`
3. Go to **Plugins** in your WordPress Admin Dashboard
4. Find **WP-Ban (Updated)** and click **Activate**

## Configuration

After activation, go to **Settings > Ban** in your WordPress Admin Dashboard.

### Available Settings

| Setting | Description |
|---------|-------------|
| **Banned Referers** | Block visitors coming from specific URLs |
| **Banned Host Names** | Block by hostname (supports wildcards) |
| **Banned IPs** | Block specific IP addresses (supports wildcards) |
| **Banned IP Range** | Block IP ranges (format: `start-end`) |
| **Banned User Agentstrings** | Block full user agent strings |
| **Useragents to Block** | Block bots/crawlers using patterns |
| **Allowed User Agents** | Whitelist user agents (overrides bans) |
| **Banned Message** | Custom HTML message shown to banned visitors |

### Wildcard Support

Use `*` as a wildcard in most fields:

- `192.168.1.*` - Matches any IP starting with 192.168.1
- `*Blexbot*` - Matches any user agent containing "Blexbot"
- `*.cn` - Matches any hostname ending with .cn

## Usage Examples

### Block Common Bad Bots

Add these to **Useragents to Block**:

```
*Blexbot*
*Python*
*python-requests*
*Scrapy*
*curl*
*wget*
*MJ12bot*
*AhrefsBot*
*SemrushBot*
*DotBot*
*DataForSeoBot*
*PetalBot*
*Bytespider*
```

### Allow Search Engine Bots

Add these to **Allowed User Agents**:

```
*Googlebot*
*Bingbot*
*Slurp*
*DuckDuckBot*
```

### Block Countries by Hostname

Add these to **Banned Host Names**:

```
*.cn
*.ru
*.th
```

### Block IP Range

Add to **Banned IP Range**:

```
192.168.1.1-192.168.1.255
10.0.0.1-10.0.0.100
```

## Common Bad Bots Reference

| Bot | Description |
|-----|-------------|
| `*Blexbot*` / `*BLEXBot*` | SEO crawler |
| `*Python*` / `*python-requests*` | Python scripts/scrapers |
| `*Scrapy*` | Python scraping framework |
| `*curl*` / `*wget*` | Command-line tools |
| `*Go-http-client*` | Go language HTTP client |
| `*Java*` / `*HttpClient*` | Java-based bots |
| `*libwww-perl*` | Perl scripts |
| `*MJ12bot*` | Majestic SEO bot |
| `*AhrefsBot*` | Ahrefs SEO crawler |
| `*SemrushBot*` | SEMrush crawler |
| `*DotBot*` | Moz crawler |
| `*MegaIndex*` | MegaIndex bot |
| `*DataForSeoBot*` | DataForSEO crawler |
| `*PetalBot*` | Huawei search bot |
| `*Bytespider*` | ByteDance crawler |
| `*Nimbostratus-Bot*` | Cloud service bot |
| `*Seekport*` | Seekport crawler |
| `*ZoominfoBot*` | ZoomInfo data collector |

## Banned Message Variables

Customize your banned message using these variables:

| Variable | Description |
|----------|-------------|
| `%SITE_NAME%` | Your site's name |
| `%SITE_URL%` | Your site's URL |
| `%USER_IP%` | Visitor's IP address |
| `%USER_HOSTNAME%` | Visitor's hostname |

### Example Banned Message

```html
<div style="text-align: center; padding: 50px;">
    <h2>Access Denied</h2>
    <p>Your IP address (%USER_IP%) has been blocked from accessing %SITE_NAME%.</p>
    <p>If you believe this is an error, please contact the site administrator.</p>
</div>
```

## Reverse Proxy Support

If your site is behind a reverse proxy (like Cloudflare), enable the **Reverse Proxy** option to correctly detect visitor IP addresses from the `X-Forwarded-For` header.

## Important Notes

- **Don't ban yourself!** Your current user agent and IP are displayed in the settings page
- **Allowed User Agents take priority** over all ban rules
- **Test carefully** before adding broad wildcard rules
- **Admin users** with `manage_options` capability are never blocked

## Frequently Asked Questions

**Q: I accidentally banned myself. What do I do?**

A: Access your site via FTP and either:
- Deactivate the plugin by renaming the `wp-ban` folder
- Edit the database and clear the ban options

**Q: Why isn't a bot being blocked?**

A: Make sure you're using wildcards correctly. For example, use `*Blexbot*` (not just `Blexbot`) to match the bot anywhere in the user agent string.

**Q: Does this affect search engine rankings?**

A: Only if you accidentally block search engine bots. Add them to **Allowed User Agents** to be safe.

## Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher

## Changelog

### Version 2.0.0
- Added full ban enforcement functionality
- Added separate "Useragents to Block" editable field
- Added "User Agent Strings" examples section
- Renamed "Banned User Agents" to "Banned User Agentstrings"
- Added IP blocking and IP range support
- Added hostname blocking
- Improved wildcard matching
- Added reverse proxy support
- Modern security improvements

## License

GPL v2 or later

## Credits

Updated by MiniMax Agent

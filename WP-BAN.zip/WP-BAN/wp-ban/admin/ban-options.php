<?php
/**
 * Admin Options Page
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Check user permissions
if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Handle form submissions
if (isset($_POST['submit']) && wp_verify_nonce($_POST['_wpnonce'], 'wp_ban_settings')) {
    $messages = array();
    
    // Update options
    $banned_options = array(
        'reverse_proxy' => isset($_POST['reverse_proxy']) ? 1 : 0
    );
    
    $banned_referers = array_filter(array_map('esc_url_raw', explode("\n", trim($_POST['banned_referers']))));
    $banned_hostnames = array_filter(array_map('sanitize_text_field', explode("\n", trim($_POST['banned_hostnames']))));
    $banned_ips = array_filter(array_map('sanitize_text_field', explode("\n", trim($_POST['banned_ips']))));
    $banned_ip_range = array_filter(array_map('sanitize_text_field', explode("\n", trim($_POST['banned_ip_range']))));
    $banned_user_agents = array_filter(array_map('sanitize_text_field', explode("\n", trim($_POST['banned_user_agents']))));
    $allowed_user_agents = array_filter(array_map('sanitize_text_field', explode("\n", trim($_POST['allowed_user_agents']))));
    $useragents_to_block = array_filter(array_map('sanitize_text_field', explode("\n", trim($_POST['useragents_to_block']))));
    $banned_message = wp_kses_post($_POST['banned_message']);

    update_option('banned_options', $banned_options);
    update_option('banned_referers', $banned_referers);
    update_option('banned_hostnames', $banned_hostnames);
    update_option('banned_ips', $banned_ips);
    update_option('banned_ip_range', $banned_ip_range);
    update_option('banned_user_agents', $banned_user_agents);
    update_option('allowed_user_agents', $allowed_user_agents);
    update_option('useragents_to_block', $useragents_to_block);
    update_option('banned_message', $banned_message);
    
    $messages[] = __('Settings saved successfully.', 'wp-ban');
}

// Get current options
$banned_referers = get_option('banned_referers', array());
$banned_hostnames = get_option('banned_hostnames', array());
$banned_ips = get_option('banned_ips', array());
$banned_ip_range = get_option('banned_ip_range', array());
$banned_user_agents = get_option('banned_user_agents', array());
$allowed_user_agents = get_option('allowed_user_agents', array());
$useragents_to_block = get_option('useragents_to_block', array());
$banned_message = get_option('banned_message', '<div style="text-align: center; padding: 50px;"><h2>Access Denied</h2><p>You have been banned from accessing this site.</p></div>');
$banned_options = get_option('banned_options', array('reverse_proxy' => 0));

// Convert arrays to textarea format
$banned_referers_display = implode("\n", $banned_referers);
$banned_hostnames_display = implode("\n", $banned_hostnames);
$banned_ips_display = implode("\n", $banned_ips);
$banned_ip_range_display = implode("\n", $banned_ip_range);
$banned_user_agents_display = implode("\n", $banned_user_agents);
$allowed_user_agents_display = implode("\n", $allowed_user_agents);
$useragents_to_block_display = implode("\n", $useragents_to_block);

$current_user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : __('Unknown', 'wp-ban');
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <?php if (!empty($messages)) : ?>
        <?php foreach ($messages as $message) : ?>
            <div class="notice notice-success is-dismissible">
                <p><?php echo esc_html($message); ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Current User Information -->
    <div class="postbox">
        <h2 class="hndle"><?php _e('Your Current Information', 'wp-ban'); ?></h2>
        <div class="inside">
            <table class="form-table">
                <tr>
                    <th><?php _e('User Agent', 'wp-ban'); ?>:</th>
                    <td><strong><?php echo esc_html($current_user_agent); ?></strong></td>
                </tr>
            </table>
            <p class="description"><strong><?php _e('Warning:', 'wp-ban'); ?></strong> <?php _e('Do not ban your own user agent.', 'wp-ban'); ?></p>
        </div>
    </div>

    <!-- Main Settings Form -->
    <form method="post" action="">
        <?php wp_nonce_field('wp_ban_settings'); ?>
        
        <div class="postbox">
            <h2 class="hndle"><?php _e('Ban Settings', 'wp-ban'); ?></h2>
            <div class="inside">
                
                <table class="form-table">
                    
                    <!-- Banned Referers -->
                    <tr>
                        <th scope="row">
                            <label for="banned_referers"><?php _e('Banned Referers', 'wp-ban'); ?></label>
                        </th>
                        <td>
                            <textarea id="banned_referers" name="banned_referers" rows="6" cols="50" class="large-text"><?php echo esc_textarea($banned_referers_display); ?></textarea>
                            <p class="description"><?php _e('Enter referer URLs (one per line). Use * for wildcards.', 'wp-ban'); ?></p>
                        </td>
                    </tr>

                    <!-- Example Referers to Block -->
                    <tr>
                        <th scope="row">
                            <label><?php _e('Example Referers to Block', 'wp-ban'); ?></label>
                        </th>
                        <td>
                            <textarea readonly rows="4" cols="50" class="large-text" style="background:#f9f9f9; font-family:monospace;">http://*.blogspot.com</textarea>
                            <p class="description"><?php _e('Copy any of these examples and paste them into the "Banned Referers" field above.', 'wp-ban'); ?></p>
                        </td>
                    </tr>

                    <!-- Banned Host Names -->
                    <tr>
                        <th scope="row">
                            <label for="banned_hostnames"><?php _e('Banned Host Names', 'wp-ban'); ?></label>
                        </th>
                        <td>
                            <textarea id="banned_hostnames" name="banned_hostnames" rows="6" cols="50" class="large-text"><?php echo esc_textarea($banned_hostnames_display); ?></textarea>
                            <p class="description"><?php _e('Use * for wildcards. Start each entry on a new line.', 'wp-ban'); ?></p>
                        </td>
                    </tr>

                    <!-- Example Host Names to Block -->
                    <tr>
                        <th scope="row">
                            <label><?php _e('Example Host Names to Block', 'wp-ban'); ?></label>
                        </th>
                        <td>
                            <textarea readonly rows="4" cols="50" class="large-text" style="background:#f9f9f9; font-family:monospace;">*.sg
*.cn
*.th</textarea>
                            <p class="description"><?php _e('Copy any of these examples and paste them into the "Banned Host Names" field above.', 'wp-ban'); ?></p>
                        </td>
                    </tr>

                    <!-- Banned IPs -->
                    <tr>
                        <th scope="row">
                            <label for="banned_ips"><?php _e('Banned IPs', 'wp-ban'); ?></label>
                        </th>
                        <td>
                            <textarea id="banned_ips" name="banned_ips" rows="6" cols="50" class="large-text"><?php echo esc_textarea($banned_ips_display); ?></textarea>
                            <p class="description"><?php _e('Use * for wildcards. Start each entry on a new line.', 'wp-ban'); ?></p>
                        </td>
                    </tr>

                    <!-- Example IPs to Block -->
                    <tr>
                        <th scope="row">
                            <label><?php _e('Example IPs to Block', 'wp-ban'); ?></label>
                        </th>
                        <td>
                            <textarea readonly rows="4" cols="50" class="large-text" style="background:#f9f9f9; font-family:monospace;">192.168.1.100
192.168.1.*
192.168.*.*</textarea>
                            <p class="description"><?php _e('Copy any of these examples and paste them into the "Banned IPs" field above.', 'wp-ban'); ?></p>
                        </td>
                    </tr>

                    <!-- Banned IP Range -->
                    <tr>
                        <th scope="row">
                            <label for="banned_ip_range"><?php _e('Banned IP Range', 'wp-ban'); ?></label>
                        </th>
                        <td>
                            <textarea id="banned_ip_range" name="banned_ip_range" rows="6" cols="50" class="large-text"><?php echo esc_textarea($banned_ip_range_display); ?></textarea>
                            <p class="description"><?php _e('Start each entry on a new line. No wildcards allowed.', 'wp-ban'); ?></p>
                        </td>
                    </tr>

                    <!-- Example IP Ranges to Block -->
                    <tr>
                        <th scope="row">
                            <label><?php _e('Example IP Ranges to Block', 'wp-ban'); ?></label>
                        </th>
                        <td>
                            <textarea readonly rows="2" cols="50" class="large-text" style="background:#f9f9f9; font-family:monospace;">192.168.1.1-192.168.1.255</textarea>
                            <p class="description"><?php _e('Copy any of these examples and paste them into the "Banned IP Range" field above.', 'wp-ban'); ?></p>
                        </td>
                    </tr>

                    <!-- Banned User Agents -->
                    <tr>
                        <th scope="row">
                            <label for="banned_user_agents"><?php _e('Banned User Agentstrings', 'wp-ban'); ?></label>
                        </th>
                        <td>
                            <textarea id="banned_user_agents" name="banned_user_agents" rows="10" cols="50" class="large-text"><?php echo esc_textarea($banned_user_agents_display); ?></textarea>
                            <p class="description"><?php _e('Enter browser/user agent strings (one per line). Use * for wildcards.', 'wp-ban'); ?></p>
                        </td>
                    </tr>

                    <!-- User Agent Strings -->
                    <tr>
                        <th scope="row">
                            <label><?php _e('User Agent Strings', 'wp-ban'); ?></label>
                        </th>
                        <td>
                            <textarea readonly rows="3" cols="50" class="large-text" style="background:#f9f9f9; font-family:monospace; font-size:11px;">Mozilla/5.0 (Linux; U; Android 1.5; en-ca; Build/CUPCAKE) AppleWebKit/528.5+ (KHTML, like Gecko) Version/3.1.2 Mobile Safari/525.20.1
Mozilla/5.0 (iPad; CPU iPad OS 17_4 like Mac OS X) AppleWebKit/533.2 (KHTML, like Gecko) CriOS/28.0.827.0 Mobile/34B232 Safari/533.2</textarea>
                            <p class="description"><?php _e('These are examples of full user agent strings sent by browsers.', 'wp-ban'); ?></p>
                        </td>
                    </tr>

                    <!-- Useragents to Block -->
                    <tr>
                        <th scope="row">
                            <label for="useragents_to_block"><?php _e('Useragents to Block', 'wp-ban'); ?></label>
                        </th>
                        <td>
                            <textarea id="useragents_to_block" name="useragents_to_block" rows="14" cols="50" class="large-text"><?php echo esc_textarea($useragents_to_block_display); ?></textarea>
                            <p class="description"><?php _e('Enter useragent patterns to block (one per line). Use * as wildcards. Examples: *Blexbot*, *Python*, *DataForSeoBot*', 'wp-ban'); ?></p>
                        </td>
                    </tr>

                    <!-- Allowed User Agents -->
                    <tr>
                        <th scope="row">
                            <label for="allowed_user_agents"><?php _e('Allowed User Agents', 'wp-ban'); ?></label>
                        </th>
                        <td>
                            <textarea id="allowed_user_agents" name="allowed_user_agents" rows="10" cols="50" class="large-text"><?php echo esc_textarea($allowed_user_agents_display); ?></textarea>
                            <p class="description"><?php _e('User agents that should NEVER be banned (one per line). Use * for wildcards. These take priority over banned user agents.', 'wp-ban'); ?></p>
                            <p><strong><?php _e('Examples (search engine bots):', 'wp-ban'); ?></strong><br>
                            *Googlebot*<br>
                            *Bingbot*<br>
                            *Slurp*<br>
                            *DuckDuckBot*</p>
                        </td>
                    </tr>

                    <!-- Banned Message -->
                    <tr>
                        <th scope="row">
                            <label for="banned_message"><?php _e('Banned Message', 'wp-ban'); ?></label>
                        </th>
                        <td>
                            <?php wp_editor($banned_message, 'banned_message', array(
                                'textarea_rows' => 10,
                                'media_buttons' => false,
                                'textarea_name' => 'banned_message',
                                'teeny' => true
                            )); ?>
                            <p class="description">
                                <?php _e('Available variables:', 'wp-ban'); ?> %SITE_NAME%, %SITE_URL%, %USER_IP%, %USER_HOSTNAME%, %USER_ATTEMPTS_COUNT%, %TOTAL_ATTEMPTS_COUNT%
                            </p>
                        </td>
                    </tr>

                </table>
            </div>
        </div>

        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button-primary" value="<?php _e('Save Changes', 'wp-ban'); ?>">
        </p>
    </form>
</div>
